# -*- coding: utf-8 -*-
"""
Created on Wed May 27 16:29:48 2020

@author: qtckp
"""

from PersianG2p import PersianG2Pconverter


